package com.jr.uhf;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.jr.bluetooth.ConnectedThread;
import com.jr.uhf.command.InventoryInfo;
import com.jr.uhf.command.NewSendCommendManager;
import com.jr.uhf.command.Tools;
import com.jr.uhf.util.Util;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class ReadActivity extends Activity {
	
	/* UI �ؼ� */
	private TextView textTitle ; 				 //����
	private CheckBox checkTag ;					//�Ƿ�ѡ��ǩ
	private Button buttonReadTag;				//����ǩ��ť
	private EditText editTag ;					//��ǩ�������
	private Spinner spinnerMembank;				//�洢��
	private EditText editAccess;				//����
	private EditText editAddr;					//��ʼ��ַ
	private EditText editLen;					//��ȡ���ݳ���
	private EditText editReadData; 				//������ʾ
	private Button buttonReadData;				//�����ݰ�ť	
	
	private InputStream is ;					//����������
	private OutputStream os ;					//���������
	private NewSendCommendManager manager ;		//����Ƶָ����
	
	private int membank = 0;
	private int addr = 0;						//��ʼ��ַ
	private int len = 1;						//��ȡ���ݳ���
	private byte[] accessPassword ;				//��������
	
	
	
	private String[] membanks ;
	private List<String> listMembank = new ArrayList<String>();
	
	private Handler mHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case BluetoothActivity.CONNECT_INTERRUPT:// �����ж�
				BluetoothActivity.connFlag = false;
				Toast.makeText(getApplicationContext(), "�����ж�",
						Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			}			
		};
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_read_tag);
		textTitle = (TextView) findViewById(R.id.textView_title);
		textTitle.setText(R.string.readData);
		textTitle.append("--������");
		//������Ϣ����
		ConnectedThread.setHandler(mHandler);
		membanks = getResources().getStringArray(R.array.membanks);
		for(String membankItem : membanks){
			listMembank.add(membankItem);
		}
		//��ʼUI
		initUI();
		is = ConnectedThread.getSocketInoutStream();
		os = ConnectedThread.getSocketOutoutStream();
		manager = new NewSendCommendManager(is, os);
		//������ť
		listner();
		//��ʼ��������
		Util.initSoundPool(this);
		
	}

	//��ʼUI
	private void initUI(){
		checkTag = (CheckBox) findViewById(R.id.checkBox_select);
		buttonReadTag = (Button) findViewById(R.id.button_read_tag);
		editTag = (EditText) findViewById(R.id.editText_tag);
		spinnerMembank = (Spinner) findViewById(R.id.spinner_menbank);
		editAccess = (EditText) findViewById(R.id.editText_read_access);
		editAddr = (EditText) findViewById(R.id.editText_read_addr);
		editLen = (EditText) findViewById(R.id.editText_read_len);
		editReadData = (EditText) findViewById(R.id.editText_read_data);
		buttonReadData = (Button)findViewById(R.id.button_read_data);
		//��������
		spinnerMembank.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_dropdown_item_1line,
				listMembank));
	}
	//������ť
	private void listner(){
		//����ǩ
		buttonReadTag.setOnClickListener(new OnReadTagListner());
		//������
		buttonReadData.setOnClickListener(new onReadDataListener());
		//���ݴ洢��ѡ��
		spinnerMembank.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> adapter, View view,
					int position, long id) {
				String membankStr = listMembank.get(position);
//				Log.e(TAG, membankStr);
				if("RESEVER".equals(membankStr)){
					membank = NewSendCommendManager.RESEVER_MENBANK;
				}else if("EPC".equals(membankStr)){
					membank = NewSendCommendManager.EPC_MEMBANK;
				}else if("TID".equals(membankStr)){
					membank = NewSendCommendManager.TID_MEMBANK;
				}else if("USER".equals(membankStr)){
					membank = NewSendCommendManager.USER_MENBANK;
				}
//				Log.e(TAG, membankStr + membank);
			}

			@Override
			public void onNothingSelected(AdapterView<?> adapter) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	private List<InventoryInfo> listTag = new ArrayList<InventoryInfo>(); //�̴��ǩ
	private static final String TAG = "ReadActivity";
	//����ǩ
	private class OnReadTagListner implements OnClickListener{
		@Override
		public void onClick(View arg0) {

			//�������ӶϿ�
			if(!BluetoothActivity.connFlag){
				return;
			}
			//�����������Ϊnull
			if(is != null && os != null){
				listTag = manager.inventoryRealTime();
				if(listTag != null && !listTag.isEmpty()){
					String epcStr = Tools.Bytes2HexString(listTag.get(0).getEpc(), listTag.get(0).getEpc().length);
					editTag.setText(epcStr);
					Log.e(TAG, "epcStr = " + epcStr);
				}
			}
			
		}
	}
	//������
	private class onReadDataListener implements OnClickListener{
		byte[] readdata ;
		@Override
		public void onClick(View arg0) {
			String passwordStr = editAccess.getText().toString();
			String addrStr = editAddr.getText().toString();
			String lenStr = editLen.getText().toString();
			if(passwordStr == null){
				Toast.makeText(getApplicationContext(), "���벻��Ϊnull", 0).show();
				return ;
			}
			if(addrStr == null){
				Toast.makeText(getApplicationContext(), "��ʼ��ַ����Ϊnull", 0).show();
				return ;
			}
			if(lenStr == null){
				Toast.makeText(getApplicationContext(), "���Ȳ���Ϊnull", 0).show();
				return ;
			}
			accessPassword = Tools.HexString2Bytes(passwordStr);
			addr = Integer.valueOf(addrStr);
			len = Integer.valueOf(lenStr);
			if(len == 0){
				Toast.makeText(getApplicationContext(), "���Ȳ���Ϊ0", 0).show();
				return;
			}
			//У�����볤���Ƿ���ȷ
			if(accessPassword.length != 4){
				Toast.makeText(getApplicationContext(), "���볤�Ȳ���", 0).show();
				return;
			}
			//�������ӶϿ�
			if(!BluetoothActivity.connFlag){
				return;
			}
			//
			try{
				readdata = ReadActivity.this.readData(membank, addr, len, accessPassword);
			}catch(Exception e){
				//�����쳣
			}
			
			if(readdata != null && readdata.length > 1){
				Util.play(1, 0);
				Toast.makeText(getApplicationContext(), "�����ݳɹ�", 0).show();
				editReadData.setText(Tools.Bytes2HexString(readdata, readdata.length));
			}else{
				Toast.makeText(getApplicationContext(), "������ʧ�ܣ�������"+ readdata[0], 0).show();
			}
		}
		
	}
	
	/*
	 * ����ǩ
	 */
	private byte[] readData(int membank, int address, int length , byte[] password ){
		byte[] data = null;
		/**
		 * ����Ƶ��д���ݺ����׶�дʧ�ܣ�����Զ�д���������Ͷ�дʧ�ܵĴ���
		 */
		for(int i = 0; i < 3; i++){
			data = manager.readFrom6C(membank, address, length, password);
			//�����ݳɹ�������ѭ��
			if(data != null){
				Log.e(TAG, "data = " + Tools.Bytes2HexString(data, data.length));
				break;
			}
		}
		return data;
	}
	
	
}
