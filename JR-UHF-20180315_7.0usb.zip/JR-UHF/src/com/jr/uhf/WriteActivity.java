package com.jr.uhf;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.jr.bluetooth.ConnectedThread;
import com.jr.uhf.command.InventoryInfo;
import com.jr.uhf.command.NewSendCommendManager;
import com.jr.uhf.command.Tools;
import com.jr.uhf.util.Util;

public class WriteActivity extends Activity {
	/* UI �ؼ� */
	private TextView textTitle;
	private CheckBox checkTag;
	private Button buttonReadTag;
	private EditText editTag;
	private Spinner spinnerMembank;
	private EditText editAccess;
	private EditText editAddr;
	private EditText editLen;
	private EditText editWriteData;
	private Button buttonReadData;

	private String[] membanks;
	private List<String> listMembank = new ArrayList<String>();
	private int membank; // ������
	private InputStream is ;					//����������
	private OutputStream os ;					//���������
	private NewSendCommendManager manager; // ����Ƶָ�����
	private byte[] writeData; // д�������

	private final String TAG = "WriteActivity";

	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case BluetoothActivity.CONNECT_INTERRUPT:// �����ж�
				BluetoothActivity.connFlag = false;
				Toast.makeText(getApplicationContext(), "�����ж�",
						Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_write_tag);
		textTitle = (TextView) findViewById(R.id.textView_title);
		textTitle.setText(R.string.write_data);
		// ������Ϣ����
		ConnectedThread.setHandler(mHandler);
		membanks = getResources().getStringArray(R.array.membanks);
		for (String membankItem : membanks) {
			listMembank.add(membankItem);
		}
		// ��ʼUI
		initUI();
		is = ConnectedThread.getSocketInoutStream();
		os = ConnectedThread.getSocketOutoutStream();
		manager = new NewSendCommendManager(is, os);
		//������ť
		 listner() ;
		 //��ʼ��������
		 Util.initSoundPool(this);
	}

	private void initUI() {
		checkTag = (CheckBox) findViewById(R.id.checkBox_write_select);
		buttonReadTag = (Button) findViewById(R.id.button_write_read_tag);
		editTag = (EditText) findViewById(R.id.editText_write_tag);
		spinnerMembank = (Spinner) findViewById(R.id.spinner_menbank_write);
		editAccess = (EditText) findViewById(R.id.editText_write_read_access);
		editAddr = (EditText) findViewById(R.id.editText_write_read_addr);
		editLen = (EditText) findViewById(R.id.editText_write_read_len);
		editWriteData = (EditText) findViewById(R.id.editText_write_data);
		buttonReadData = (Button) findViewById(R.id.button_write_data);

		// ��������
		spinnerMembank.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_dropdown_item_1line, listMembank));
	}

	// ������ť
	private void listner() {
		// ����ǩ
		 buttonReadTag.setOnClickListener(new OnReadTagListner());
		// д����
		 buttonReadData.setOnClickListener(new onWriteDataListener());
		// ���ݴ洢��ѡ��
		spinnerMembank.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> adapter, View view,
					int position, long id) {
				String membankStr = listMembank.get(position);
				// Log.e(TAG, membankStr);
				if ("RESEVER".equals(membankStr)) {
					membank = NewSendCommendManager.RESEVER_MENBANK;
				} else if ("EPC".equals(membankStr)) {
					membank = NewSendCommendManager.EPC_MEMBANK;
				} else if ("TID".equals(membankStr)) {
					membank = NewSendCommendManager.TID_MEMBANK;
				} else if ("USER".equals(membankStr)) {
					membank = NewSendCommendManager.USER_MENBANK;
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> adapter) {
				// TODO Auto-generated method stub

			}
		});
	}

	private byte[] accessPassword; //
	private int addr;
	private int len;
	
	private List<InventoryInfo> listTag ;
	//����ǩ
	private class OnReadTagListner implements OnClickListener{
		@Override
		public void onClick(View arg0) {

			//�������ӶϿ�
			if(!BluetoothActivity.connFlag){
				return;
			}
			//�����������Ϊnull
			if(is != null && os != null){
				listTag = manager.inventoryRealTime();
				if(listTag != null && !listTag.isEmpty()){
					String epcStr = Tools.Bytes2HexString(listTag.get(0).getEpc(), listTag.get(0).getEpc().length);
					editTag.setText(epcStr);
					Log.e(TAG, "epcStr = " + epcStr);
				}
			}
			
		}
	}
	
	// д��������
	private class onWriteDataListener implements OnClickListener {
		boolean writeFlag = false;

		@Override
		public void onClick(View arg0) {
			String passwordStr = editAccess.getText().toString();
			String addrStr = editAddr.getText().toString();
			String dataStr = editWriteData.getText().toString();
			if(passwordStr == null){
				Toast.makeText(getApplicationContext(), "���벻��Ϊnull", 0).show();
				return ;
			}
			if(addrStr == null){
				Toast.makeText(getApplicationContext(), "��ʼ��ַ����Ϊnull", 0).show();
				return ;
			}
			accessPassword = Tools.HexString2Bytes(passwordStr);
			addr = Integer.valueOf(addrStr);
			// У�����볤���Ƿ���ȷ
			if (accessPassword.length != 4) {
				Toast.makeText(getApplicationContext(), "���볤�Ȳ���", 0).show();
				return;
			}
			if (dataStr == null || "".equals(dataStr)) {
				Toast.makeText(getApplicationContext(), "д�����ݲ���Ϊ��", 0).show();
				return;
			}
			int dataStrLen = dataStr.length();
			// data�����Ƿ�Ϊ4����������1word������������0
			int syCount = dataStrLen % 4;
			if (syCount != 0) {
				for (int i = 0; i < syCount; i++) {
					dataStr = dataStr + "0";
				}
			}
			writeData = Tools.HexString2Bytes(dataStr);
			// �������ӶϿ�
			if (!BluetoothActivity.connFlag) {
				return;
			}
			//
			try {
				writeFlag = writeData(membank, addr, accessPassword, writeData,
						writeData.length);// д������
			} catch (Exception e) {
				// �����쳣
			}
			
			if(writeFlag){
				Toast.makeText(getApplicationContext(), "д���ݳɹ�", 0).show();
				Util.play(1, 0);//������ʾ��
			}
		}

	}

	/*
	 * д��ǩ����
	 */
	private boolean writeData(int membank, int address, byte[] password,
			byte[] data, int dataLen) {
		boolean writeFlag = false;
		/**
		 * ����Ƶ��д���ݺ����׶�дʧ�ܣ�����Զ�д���������Ͷ�дʧ�ܵĴ���
		 */
		for (int i = 0; i < 3; i++) {
			writeFlag = manager.writeTo6C(password, membank, address,
					dataLen / 2, data);
			// �����ݳɹ�������ѭ��
			if (writeFlag) {
				Log.e(TAG, "write success!!");
				break;
			}
		}
		return writeFlag;
	}

}
