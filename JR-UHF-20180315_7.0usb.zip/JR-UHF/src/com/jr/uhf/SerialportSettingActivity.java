package com.jr.uhf;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.jr.uhf.command.NewSendCommendManager;
import com.jr.uhf.command.Tools;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android_serialport_api.SerialPort;
import android_serialport_api.SerialPortFinder;

/**
 * �������ý���
 * 
 * @author Administrator
 * 
 */
public class SerialportSettingActivity extends Activity {

	/* UI�ؼ� */
	private TextView textTitle ;
	private Spinner spinnerCom;
	private Spinner spinnerBaudrate;
	private EditText editCom;
	private EditText editConnectFlag;
	private EditText editOutputPower;
	private EditText editWorkFreq;
	private Button buttonConnectDevice;
	private Button buttonInto ;

	private String[] comDevices; // �����ļ��б�
	private List<String> comPath = new ArrayList<String>();//����·���б�
	private String[] baudrateStrs; // ����������
	private List<String> baudrateList = new ArrayList<String>(); // �������б�

	private SerialPortFinder mSerialportFinder;   //�����豸����
	private SerialPort comSerialport ;	//����
	public static InputStream is ;
	public static OutputStream os ;
	private NewSendCommendManager manager ;
	
	private String serialPath ;  //����·��
	private int baudrate ;
	private final String TAG = "SerialportSettingActivity";
	
	private boolean connFlag = false ; //����״̬
	
	/** �������� **/
	private com.BRMicro.SerialPort switchSerialport ;  //H901����ת��

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		// ��ȡ�豸�����б�
		setContentView(R.layout.activity_serialport_setting);
		textTitle = (TextView) findViewById(R.id.textView_title);
		textTitle.setText(R.string.serialport_setting);
		//��ȡ����·��
		this.getSerialportDervicePath();
		// ��ʼUI
		this.initUI();
//		//����
//		test();
		//����
		listener();
	}
	
	//��H901�ϵ��Ե��Է���
//	private void test(){
//		try {
//			comSerialport = new SerialPort(new File("/dev/ttyMT1"), 115200, 0);
//			//�л���13
//			switchSerialport = new com.BRMicro.SerialPort();
//			switchSerialport.switch2channel(13);
//			//�򿪵�Դ
////			switchSerialport.rfidPoweron();
//		} catch (Exception e) {
////			e.printStackTrace();
//			Toast.makeText(getApplicationContext(), "���ڴ�ʧ��", 0).show();
//			return ;
//			
//		} 
//
//		
//		if(comSerialport == null){
//			return;
//		}
//		is = comSerialport.getInputStream();
//		os = comSerialport.getOutputStream();
//		
//		manager = new NewSendCommendManager(is, os);
//		
//	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(switchSerialport != null){
			switchSerialport.rfidPoweron();
			
		}
		super.onDestroy();
	}

	// ��ȡ�����б�
	private void getSerialportDervicePath() {
		mSerialportFinder = new SerialPortFinder();
		comDevices = mSerialportFinder.getAllDevices();
		if (comDevices != null && comDevices.length > 0) {
//			comPath = new ArrayList<String>();
			for (int i = 0; i < comDevices.length; i++) {
				comPath.add("/dev/" + comDevices[i].split(" ")[0]);
				Log.e("", comPath.get(i));
			}
		} else {
			Toast.makeText(getApplicationContext(), "��ȡ�����б�ʧ��", 0).show();
			return;
		}
	}

	// ��ʼUI
	private void initUI() {
		spinnerCom = (Spinner) findViewById(R.id.spinner_com_id);
		spinnerBaudrate = (Spinner) findViewById(R.id.spinner_baudrate);
		editCom = (EditText) findViewById(R.id.editText_com_id);
		editConnectFlag = (EditText) findViewById(R.id.editText_connected_flag);
		editOutputPower = (EditText) findViewById(R.id.editText_output_power);
		editWorkFreq = (EditText) findViewById(R.id.editText_work_freq);
		buttonConnectDevice = (Button) findViewById(R.id.button_connect);
		buttonInto = (Button) findViewById(R.id.button_into_option_reader);
		
		setButtonFlag(buttonInto, connFlag);

		spinnerCom.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_dropdown_item_1line, comPath));
		
		baudrateStrs = getResources().getStringArray(R.array.baudrate);
		for(String baudrate : baudrateStrs){
			baudrateList.add(baudrate);
		}
		spinnerBaudrate.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_dropdown_item_1line, baudrateList));
	}
	
	/**
	 * ����
	 */
	private void listener(){
		//����ѡ��
		spinnerCom.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				serialPath = comPath.get(arg2);
				editCom.setText(serialPath);
				Log.e(TAG, "serialPath = " + serialPath);
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		//������ѡ��
		spinnerBaudrate.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				baudrate = Integer.valueOf(baudrateList.get(arg2));
				Log.e(TAG, "baudrate = " + baudrateList.get(arg2));
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
		//�����豸��ť����
		buttonConnectDevice.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//1.���Ӵ���
				//2.��ȡ��������
				//3.�ı����״̬
//				byte[] version = manager.getFirmware();
//				if(version != null){
//					Toast.makeText(getApplicationContext(), "���ڴ򿪳ɹ�", 0).show();
//					editConnectFlag.setText("������");
//					setButtonFlag(buttonConnectDevice, false);
//					setButtonFlag(buttonInto, true);
//				}
//				Log.e("", manager.getOuputPower() + "");
				//��ʼ�����ڳɹ�
				if(initSerialport()){
					// ��ȡ�汾�ţ�����ģ���Ƿ�����
					byte[] version = manager.getFirmware();
					if(version == null){
					Toast.makeText(getApplicationContext(), "�豸��ʧ��", 0).show();
					return ;
				}
					editConnectFlag.setText("������");
					setButtonFlag(buttonConnectDevice, false);
					setButtonFlag(buttonInto, true);
				}else{
					Toast.makeText(getApplicationContext(), "���ڳ�ʼ��ʧ��", 0).show();
				}
				
			}
		});
		//
		buttonInto.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent toUHF = new Intent(SerialportSettingActivity.this, SerialportUHFactivity.class);
				toUHF.putExtra("mode", "serialport");
				startActivity(toUHF);
			}
		});
	}
	//���Ӵ���
	private boolean initSerialport(){
		try {
			comSerialport = new SerialPort(new File(serialPath), baudrate, 0);
		} catch (Exception e) {
			e.printStackTrace();
			Toast.makeText(getApplicationContext(), "���ڴ�ʧ��", 0).show();
			return false;
			
		} 
		
		//�л���13
//		switchSerialport = new com.BRMicro.SerialPort();
//		switchSerialport.switch2channel(13);
		
		is = comSerialport.getInputStream();
		os = comSerialport.getOutputStream();
		
		manager = new NewSendCommendManager(is, os);
		return true;
	}
	//���ð�ť������
	private void setButtonFlag(Button button, boolean flag){
		button.setClickable(flag);
		if(flag){
			button.setTextColor(getResources().getColor(R.color.black));
		}else{
			button.setTextColor(getResources().getColor(R.color.gray));
		}
	}
	
	//��ȡ����״̬��Ϣ
	private void readBasicInfo(){
		int outputPower = manager.getOuputPower();
		if(outputPower > 0){
			connFlag = true;
			//�豸���ӳɹ�
			editOutputPower.setText(outputPower + "Bdm");
			editConnectFlag.setText(R.string.connected);
			Toast.makeText(getApplicationContext(), "�豸���ӳɹ�", 0).show();
		}else{
			connFlag = false;
			//�豸���ӳɹ�
			editOutputPower.setText("");
			editConnectFlag.setText(R.string.disconnect);
			Toast.makeText(getApplicationContext(), "δ�������豸", 0).show();
		}
		setButtonFlag(buttonInto, connFlag);
	}
	
}
