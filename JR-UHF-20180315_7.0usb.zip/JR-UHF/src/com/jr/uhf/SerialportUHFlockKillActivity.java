package com.jr.uhf;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.jr.uhf.command.InventoryInfo;
import com.jr.uhf.command.NewSendCommendManager;
import com.jr.uhf.command.Tools;
import com.jr.uhf.util.Util;

//������������
public class SerialportUHFlockKillActivity extends Activity {
	/* UI �ؼ� */
	private TextView textTitle; // ����
	private CheckBox checkTag; // �Ƿ�ѡ��ǩ
	private Button buttonReadTag; // ����ǩ��ť
	private EditText editTag; // ��ǩ�������
	private Spinner spinnerLockMembank; // ����������
	private EditText editAccess; // ����
	private Spinner spinnerLockType; // ��������
	private Button buttonLock; // ����
	private EditText editKillPassword ; //��������
	private Button buttonKill; //����
	
	
	private String[] lockMembanks;
	private String[] lockTypes;
	private List<String> listLockMembanks = new ArrayList<String>();
	private List<String> listLockType = new ArrayList<String>();

	private int lockMem; // ������
	private int lockType; // ��������
	private byte[] accessBytes;// ��������
	private byte[] killBytes ;//��������
//	private NewSendCommendManager cmdManager = new NewSendCommendManager(
//			SerialportSettingActivity.is, SerialportSettingActivity.os);
	private NewSendCommendManager cmdManager = null;
	String mode ;
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_serialport_lock_kill_activity);
		textTitle = (TextView) findViewById(R.id.textView_title);
		mode = getIntent().getStringExtra("mode");
		if("usb".equals(mode)){
			textTitle.setText("USB-����/���ٱ�ǩ");
//			cmdManager = new NewSendCommendManager(
//			UsbSettingActivity.getInputStream(), UsbSettingActivity.getOutputStream());
	cmdManager = new NewSendCommendManager(UsbSettingActivity.mSerial) ;
		}else if("serialport".endsWith(mode)){
			textTitle.setText("����-����/���ٱ�ǩ");
			cmdManager = new NewSendCommendManager(
					SerialportSettingActivity.is, SerialportSettingActivity.os);
		}
		
		lockMembanks = getResources().getStringArray(R.array.lock_membank);
		for (String membank : lockMembanks) {
			listLockMembanks.add(membank);
		}
		lockTypes = getResources().getStringArray(R.array.lock_type);
		for (String lockType : lockTypes) {
			listLockType.add(lockType);
		}
		//init UI
		// ��ʼ��UI
		initUI();
		// ����
		listener();
		//��ʼ��������
		Util.initSoundPool(this);
	}
	private void initUI() {
		checkTag = (CheckBox) findViewById(R.id.checkBox_lock_kill_select);
		buttonReadTag = (Button) findViewById(R.id.button_lock_kill_read_tag);
		editTag = (EditText) findViewById(R.id.editText_lock_kill_tag);
		spinnerLockMembank = (Spinner) findViewById(R.id.spinner_lock_kill_membank);
		editAccess = (EditText) findViewById(R.id.editText_lock_kill_access_password);
		spinnerLockType = (Spinner) findViewById(R.id.spinner_lock_kill_type);
		buttonLock = (Button) findViewById(R.id.button_lock_kill_lock);
		buttonKill = (Button) findViewById(R.id.button_lock_kill_kill);
		editKillPassword = (EditText) findViewById(R.id.editText_lock_kill_access_password);
		
		spinnerLockMembank.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_dropdown_item_1line, listLockMembanks));
		spinnerLockType.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_dropdown_item_1line, listLockType));

	}
	
private String TAG = "LockActivity";
	
	private void listener() {
		
		//����ǩ
		buttonReadTag.setOnClickListener(new OnReadTagListner());
		//������
		spinnerLockMembank.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> adapter, View view,
					int position, long id) {
				
				String mem = listLockMembanks.get(position);
				if("��������".equals(mem)){
					lockMem = NewSendCommendManager.LOCK_MEM_KILL;
				}else if("��������".equals(mem)){
					lockMem = NewSendCommendManager.LOCK_MEM_ACCESS;
				}else if("EPC��".equals(mem)){
					lockMem = NewSendCommendManager.LOCK_MEM_EPC;
				}else if("TID��".equals(mem)){
					lockMem = NewSendCommendManager.LOCK_MEM_TID;
				}else if("USER��".equals(mem)){
					lockMem = NewSendCommendManager.LOCK_MEM_USER;
				}
				Log.e(TAG, lockMem + "");
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		//��������
		spinnerLockType.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> adapter, View view,
					int position, long id) {
				String type = listLockType.get(position);
				if("����".equals(type)){
					lockType = NewSendCommendManager.LOCK_TYPE_OPEN;
				}else if("���ÿ���".equals(type)){
					lockType = NewSendCommendManager.LOCK_TYPE_PERMA_OPEN;
				}else if("����".equals(type)){
					lockType = NewSendCommendManager.LOCK_TYPE_LOCK;
				}else if("��������".equals(type)){
					lockType = NewSendCommendManager.LOCK_TYPE_PERMA_LOCK;
				}
				Log.e(TAG, lockType + "");
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		//������ǩ
		buttonLock.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String accessStr = editAccess.getText().toString();
				String epc = editTag.getText().toString();
				if(accessStr == null && accessStr.length() != 8){
					Toast.makeText(getApplicationContext(), "�������벻��Ϊ��,��Ϊ8λʮ������", 0).show();
					return;
				}
				if(epc == null && "".equals(epc) && listTag.isEmpty()){
					Toast.makeText(getApplicationContext(), "����ѡ���ǩ", 0).show();
					return;
				}
				accessBytes = Tools.HexString2Bytes(accessStr);
				
				//��ѡ��EPC
				cmdManager.selectEPC(listTag.get(0).getEpc());
				//����
				boolean lockFlag = cmdManager.lock6C(accessBytes, lockMem, lockType);
				if(lockFlag){
					Util.play(1, 0);
					Toast.makeText(getApplicationContext(), "�����ɹ�", 0).show();
				}else{
					Toast.makeText(getApplicationContext(), "����ʧ��", 0).show();
				}
			}
		});
		//���ٱ�ǩ
		buttonKill.setOnClickListener(new onKillTagListener());
	}
	
	//���ٱ�ǩ
	private class onKillTagListener implements OnClickListener{

		@Override
		public void onClick(View arg0) {
			String killStr = editKillPassword.getText().toString();
			String epc = editTag.getText().toString();
			if(killStr == null && killStr.length() != 8){
				Toast.makeText(getApplicationContext(), "�������벻��Ϊ��,��Ϊ8λʮ������", 0).show();
				return;
			}
			if(epc == null && "".equals(epc) && listTag.isEmpty()){
				Toast.makeText(getApplicationContext(), "����ѡ���ǩ", 0).show();
				return;
			}
			killBytes = Tools.HexString2Bytes(killStr);
			
			//��ѡ��EPC
			cmdManager.selectEPC(listTag.get(0).getEpc());
			//����
			boolean lockFlag = cmdManager.killTag(killBytes);
			if(lockFlag){
				Toast.makeText(getApplicationContext(), "���ٱ�ǩ�ɹ�", 0).show();
			}else{
				Toast.makeText(getApplicationContext(), "���ٱ�ǩʧ��", 0).show();
			}
			
		}
		
	}
	
	
	private List<InventoryInfo> listTag ;
	// ����ǩ
	private class OnReadTagListner implements OnClickListener {
		@Override
		public void onClick(View arg0) {
			// �����������Ϊnull
			listTag = cmdManager.inventoryRealTime();
			if (listTag != null && !listTag.isEmpty()) {
				Util.play(1, 0);// ��ʾ��
				String epcStr = Tools.Bytes2HexString(listTag.get(0).getEpc(),
						listTag.get(0).getEpc().length);
				editTag.setText(epcStr);
				Log.i(TAG, "epcStr = " + epcStr);
			}

		}
	}
}
