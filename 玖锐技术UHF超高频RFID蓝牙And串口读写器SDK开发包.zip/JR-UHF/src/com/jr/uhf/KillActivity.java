package com.jr.uhf;

import java.util.List;

import com.jr.bluetooth.ConnectedThread;
import com.jr.uhf.InventoryTagActivity.ButtonreadtagListner;
import com.jr.uhf.command.InventoryInfo;
import com.jr.uhf.command.NewSendCommendManager;
import com.jr.uhf.command.Tools;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class KillActivity extends Activity {

	private TextView textTitle;
	private EditText editTag;
	private Button buttonReadTag;
	private EditText editKillPassword;
	private Button buttonKill;

	private NewSendCommendManager cmdManager;
	private String TAG = "KillActivity";

	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case BluetoothActivity.CONNECT_INTERRUPT:// �����ж�
				BluetoothActivity.connFlag = false;
				Toast.makeText(getApplicationContext(), "�����ж�",
						Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_kill_tag);
		textTitle = (TextView) findViewById(R.id.textView_title);
		textTitle.setText("���ٱ�ǩ");
		// ��ʼUI
		initUI();
		ConnectedThread.setHandler(mHandler);
		cmdManager = new NewSendCommendManager(
				ConnectedThread.getSocketInoutStream(),
				ConnectedThread.getSocketOutoutStream());
		// ����
		listener();
	}

	private void initUI() {
		editTag = (EditText) findViewById(R.id.editText_kill_tag);
		buttonReadTag = (Button) findViewById(R.id.button_kill_read_tag);
		editKillPassword = (EditText) findViewById(R.id.editText_kill_access_password);
		buttonKill = (Button) findViewById(R.id.button_kill);
	}

	private void listener() {
		buttonReadTag.setOnClickListener(new OnReadTagListner());
		buttonKill.setOnClickListener(new onKillTagListener());
	}

	private byte[] password ;
	//���ٱ�ǩ
	private class onKillTagListener implements OnClickListener{

		@Override
		public void onClick(View arg0) {
			String accessStr = editKillPassword.getText().toString();
			String epc = editTag.getText().toString();
			if(accessStr == null && accessStr.length() != 8){
				Toast.makeText(getApplicationContext(), "�������벻��Ϊ��,��Ϊ8λʮ������", 0).show();
				return;
			}
			if(epc == null && "".equals(epc) && listTag.isEmpty()){
				Toast.makeText(getApplicationContext(), "����ѡ���ǩ", 0).show();
				return;
			}
			password = Tools.HexString2Bytes(accessStr);
			
			//��ѡ��EPC
			cmdManager.selectEPC(listTag.get(0).getEpc());
			//����
			boolean lockFlag = cmdManager.killTag(password);
			if(lockFlag){
				Toast.makeText(getApplicationContext(), "���ٱ�ǩ�ɹ�", 0).show();
			}else{
				Toast.makeText(getApplicationContext(), "���ٱ�ǩʧ��", 0).show();
			}
			
		}
		
	}
	
	private List<InventoryInfo> listTag;

	// ����ǩ
	private class OnReadTagListner implements OnClickListener {
		@Override
		public void onClick(View arg0) {

			// �������ӶϿ�
			if (!BluetoothActivity.connFlag) {
				return;
			}
			// �����������Ϊnull
			// if(is != null && os != null){
			listTag = cmdManager.inventoryRealTime();
			if (listTag != null && !listTag.isEmpty()) {
				String epcStr = Tools.Bytes2HexString(listTag.get(0).getEpc(),
						listTag.get(0).getEpc().length);
				editTag.setText(epcStr);
				Log.e(TAG, "epcStr = " + epcStr);
				// }
			}

		}
	}

}
