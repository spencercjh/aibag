/** Automatically generated file. DO NOT MODIFY */
package com.jr.uhf;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}