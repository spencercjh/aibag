package com.jr.uhf;

import android.app.Activity;
import android.os.Bundle;

/**
 * ��������
 * @author Administrator
 *
 */
public class ParaSettingActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

}
