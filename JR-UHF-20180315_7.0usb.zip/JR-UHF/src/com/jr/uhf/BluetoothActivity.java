package com.jr.uhf;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.jr.bluetooth.AcceptThread;
import com.jr.bluetooth.ConnectThread;
import com.jr.bluetooth.ConnectedThread;

public class BluetoothActivity extends Activity {
	private BluetoothAdapter btAdapter;

	// ��Ϣ������ʹ�õĳ���
	private static final int FOUND_DEVICE = 1; // �����豸
	private static final int START_DISCOVERY = 2; // ��ʼ�����豸
	private static final int FINISH_DISCOVERY = 3; // ���������豸
	private static final int CONNECT_FAIL = 4; // ����ʧ��
	private static final int CONNECT_SUCCEED_P = 5; // �������ӳɹ�
	private static final int CONNECT_SUCCEED_N = 6; // �յ����ӳɹ�
	private static final int RECEIVE_MSG = 7; // �յ���Ϣ
	private static final int SEND_MSG = 8; // ������Ϣ
	public static final int CONNECT_INTERRUPT = 101; //�����ж�

	ConnectedThread connectedThread; // ��Զ���������ӳɹ�ʱ����
	ConnectThread connectThread; // �û�����б���ĳһ�Ҫ��Զ����������ʱ����
	AcceptThread acceptThread; 

	// �����豸�Ի�����ؿؼ�
	private Dialog dialog;
	private ProgressBar discoveryPro;
	private ListView foundList;
	List<BluetoothDevice> foundDevices;

	//UI�ؼ�
	ListView LvMain;
	private ArrayList<HashMap<String, String>> arrayMenu;
	private static ArrayList<String> deviceList = new ArrayList<String>();
	private SimpleAdapter adapter;
	
	private TextView textTitle ;
	
	public static boolean connFlag = false ;
	BluetoothSocket socket;

	private final int REQUEST_OPEN_BT = 101;
	
	
	private String TAG = "BluetoothActivity ";//debug
	
	//�㲥�����ߣ���������״̬��Ϣ
	private BroadcastReceiver mReceiver;
	//�����˳��ر�Activity
	private MyActivityManager manager ;

	// ��Ϣ������..�����򼦵ĸϽ�...
	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			switch (msg.what) {
			case FOUND_DEVICE:
				foundList.setAdapter(new MyAdapter(BluetoothActivity.this,
						foundDevices));
				break;
			case START_DISCOVERY:
				discoveryPro.setVisibility(View.VISIBLE);
				break;
			case FINISH_DISCOVERY:
				discoveryPro.setVisibility(View.GONE);
				break;
			case CONNECT_FAIL:
				connFlag = false;
				Toast.makeText(BluetoothActivity.this, "����ʧ��",
						Toast.LENGTH_SHORT).show();
				break;
			case CONNECT_SUCCEED_P:
			case CONNECT_SUCCEED_N:
				Log.i(TAG, "���ӳɹ�-----");
				if (msg.what == CONNECT_SUCCEED_P) {
					//�����̲߳�ΪNull
					if (acceptThread != null) {
						acceptThread.interrupt();
					}
					
					 socket = connectThread.getSocket();
					 connectedThread = new ConnectedThread(socket, mHandler);
					 connectedThread.start();
					 
				} else {
					if (connectThread != null) {
						connectThread.interrupt();
					}
					 socket = acceptThread.getSocket();
					 connectedThread = new ConnectedThread(socket, mHandler);
					 connectedThread.start();
				}

				 String deviceName = msg.getData().getString("name");
				 textTitle.setText("�����ӣ� " + deviceName);
				 connFlag = true;
				break;
			case CONNECT_INTERRUPT:
				Toast.makeText(getApplicationContext(), "�����ѶϿ�,����������", Toast.LENGTH_SHORT).show();
				 textTitle.setText("�����ѶϿ�");
				 connFlag = false;
				break;
			}
		}

	};
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bluetooth);
		manager = (MyActivityManager)getApplication();
		manager.addActivity(this);
		// ��ʼ�ؼ�
		initView();
		
		// ע��㲥������
		registerBroadReceiver();

	}
	
	@Override
	protected void onResume() {
		// ��ʼ����
		initBluetooth();
		//
		ConnectedThread.setHandler(mHandler);
		super.onResume();
	}

	/**
	 * ��ʼ�ؼ�
	 * @author jimmy
	 * @Date 2015-1-14
	 */
	private void initView() {
		textTitle = (TextView) findViewById(R.id.textView_title);
		textTitle.setText("δ�����豸");
		arrayMenu = new ArrayList<HashMap<String, String>>();

		LvMain = (ListView) findViewById(R.id.mainLv);

		// ��ʼ��arrayMenu
		String[] array = { "����","�Ͽ�", "ʶ���ǩ", "��ȡ����", "д������", "��������","������ǩ",
				"���ٱ�ǩ", "�˳�" };
		for (int i = 0; i < array.length; i++) {
			HashMap<String, String> item = new HashMap<String, String>();
			item.put("menuItem", array[i]);
			arrayMenu.add(item);
		}

		adapter = new SimpleAdapter(this, arrayMenu, // ����Դ
				R.layout.mainlv_items,// ListItem��XMLʵ��
				new String[] { "menuItem" }, // ��̬������Item��Ӧ������
				new int[] { R.id.TvMenu // �����id����
				});
		LvMain.setAdapter(adapter);
		LvMain.setOnItemClickListener(new LvMainItemClickListener());
	}

	/**
	 * �Ƿ���ͬһ̨�豸
	 * @author jimmy
	 * @Date 2015-1-14
	 * @param device
	 * @return
	 */
	private boolean isFoundDevices(BluetoothDevice device){
		if(foundDevices != null && !foundDevices.isEmpty()){
			for(BluetoothDevice devices : foundDevices){
				if(device.getAddress().equals(devices.getAddress())){
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * ע��㲥������
	 * 
	 * @author jimmy
	 * @Date 2015-1-14
	 */
	private void registerBroadReceiver() {
		// ע��㲥������
		mReceiver = new BroadcastReceiver() {

			@Override
			public void onReceive(Context arg0, Intent arg1) {
				// TODO Auto-generated method stub
				String actionStr = arg1.getAction();
				Log.e("actionStr", actionStr);
				if (actionStr.equals(BluetoothDevice.ACTION_FOUND)) {
					BluetoothDevice device = arg1
							.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
					if(!isFoundDevices(device)){
						foundDevices.add(device);
					}
					Toast.makeText(BluetoothActivity.this,
							"�ҵ������豸��" + device.getName(), Toast.LENGTH_SHORT)
							.show();
					mHandler.sendEmptyMessage(FOUND_DEVICE);
				} else if (actionStr
						.equals(BluetoothAdapter.ACTION_DISCOVERY_STARTED)) {
					mHandler.sendEmptyMessage(START_DISCOVERY);
				} else if (actionStr
						.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)) {
					mHandler.sendEmptyMessage(FINISH_DISCOVERY);
				}
			}

		};
		IntentFilter filter1 = new IntentFilter(BluetoothDevice.ACTION_FOUND);
		IntentFilter filter2 = new IntentFilter(
				BluetoothAdapter.ACTION_DISCOVERY_STARTED);
		IntentFilter filter3 = new IntentFilter(
				BluetoothAdapter.ACTION_DISCOVERY_FINISHED);

		registerReceiver(mReceiver, filter1);
		registerReceiver(mReceiver, filter2);
		registerReceiver(mReceiver, filter3);

	}

	/**
	 * ��ʼ����
	 * 
	 * @author jimmy
	 * @Date 2015-1-14
	 */
	private void initBluetooth() {
		btAdapter = BluetoothAdapter.getDefaultAdapter();
		if (btAdapter == null) {
			// �豸��֧������
			Toast.makeText(getApplicationContext(), "���豸��֧������", 0).show();
		}
		// ��������Ƿ����
		if (!btAdapter.isEnabled()) {
			Intent enableBt = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableBt, REQUEST_OPEN_BT);
		} 
	}

	/**
	 * ���������豸
	 * 
	 * @author jimmy
	 * @Date 2015-1-14
	 */
	private void connectBluetooth() {

		btAdapter.cancelDiscovery();
		btAdapter.startDiscovery();
		/*
		 * ͨ��LayoutInflater�õ��Ի����е������ؼ� ��һ��ListViewΪ�ֲ���������Ϊ����ʾ��������Ե������豸��������ʱ�ı�
		 * �ڶ���ListView��ProgressBarΪȫ�ֱ���
		 */
		LayoutInflater inflater = getLayoutInflater();
		View view = inflater.inflate(R.layout.dialog, null);
		discoveryPro = (ProgressBar) view.findViewById(R.id.discoveryPro);
		ListView bondedList = (ListView) view.findViewById(R.id.bondedList);
		foundList = (ListView) view.findViewById(R.id.foundList);

		// ������Ե������豸��ʾ����һ��ListView��
		Set<BluetoothDevice> deviceSet = btAdapter.getBondedDevices();
		final List<BluetoothDevice> bondedDevices = new ArrayList<BluetoothDevice>();
		if (deviceSet.size() > 0) {
			for (Iterator<BluetoothDevice> it = deviceSet.iterator(); it
					.hasNext();) {
				BluetoothDevice device = (BluetoothDevice) it.next();
				bondedDevices.add(device);
			}
		}
		bondedList.setAdapter(new MyAdapter(BluetoothActivity.this,
				bondedDevices));

		// ���ҵ��������豸��ʾ���ڶ���ListView��
		foundDevices = new ArrayList<BluetoothDevice>();
		foundList
				.setAdapter(new MyAdapter(BluetoothActivity.this, foundDevices));

		// ����ListView�󶨼�����
		bondedList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				BluetoothDevice device = bondedDevices.get(arg2);
				connect(device);
			}
		});
		foundList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				BluetoothDevice device = foundDevices.get(arg2);
				connect(device);

			}
		});

		AlertDialog.Builder builder = new AlertDialog.Builder(
				BluetoothActivity.this);
		builder.setMessage("��ѡ��Ҫ���ӵ������豸").setPositiveButton("ȡ��",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						btAdapter.cancelDiscovery();
					}
				});
		builder.setView(view);
		builder.create();
		dialog = builder.show();

	}

	/**
	 * ����
	 * 
	 * @author jimmy
	 * @Date 2015-1-14
	 * @param device
	 */
	public void connect(BluetoothDevice device) {
		btAdapter.cancelDiscovery();
		dialog.dismiss();
		Toast.makeText(this, "������ " + device.getName() + " ���� .... ",
				Toast.LENGTH_LONG).show();
		connectThread = new ConnectThread(device, mHandler, true);
		connectThread.start();

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		Log.e("", "requestCode = " + requestCode + "; resultCode = "
				+ resultCode);
		if (requestCode == REQUEST_OPEN_BT && resultCode != 0) {
			Toast.makeText(getApplicationContext(), "bluetooth open success!",
					0).show();
			// ��ѯ������Ե��豸
			Set<BluetoothDevice> pairedDevices = btAdapter.getBondedDevices();
			// �ж���Ҫ���豸�Ƿ����
			if (pairedDevices.size() > 0) {
				for (BluetoothDevice device : pairedDevices) {
					// ���豸���ֺ��豸��ַ����һ��ListView��
					// mArrayAdapter.add(device.getName() + "\n" +
					// device.getAddress());
					Log.e("BluetoothDevice", "Name = " + device.getName()
							+ "; Address = " + device.getAddress());
				}
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	class LvMainItemClickListener implements OnItemClickListener{

		@Override
		public void onItemClick(AdapterView<?> adapter, View view, int position,
				long id) {
			HashMap<String, String> item = (HashMap<String, String>) LvMain.getItemAtPosition(position);
			String itemStr = item.get("menuItem");			
			
			if(itemStr.equals("����")){
				if(connFlag){
					Toast.makeText(getApplicationContext(), "���ȶϿ����ӣ�������", Toast.LENGTH_SHORT).show();
				}else{
					//���������豸
					connectBluetooth();
				}
				
				
			}if(itemStr.equals("�Ͽ�")){
				if(connFlag){
					textTitle.setText("�ѶϿ�����");
					connFlag = false;
					if(socket != null){
						try {
							//�ر���������
							socket.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}else if(itemStr.equals("ʶ���ǩ")){
				if(connFlag){
					//����ǩ����
					Intent inventoryIntent = new Intent(BluetoothActivity.this, InventoryTagActivity.class);
					startActivity(inventoryIntent);
				}else{
					Toast.makeText(getApplicationContext(), "���Ƚ�������", Toast.LENGTH_SHORT);
					return;
				}
			}else if(itemStr.equals("��ȡ����")){
				if(connFlag){
					Intent readIntent = new Intent(BluetoothActivity.this, ReadActivity.class);
					startActivity(readIntent);
				}else{
					Toast.makeText(getApplicationContext(), "���Ƚ�������", Toast.LENGTH_SHORT);
					return;
				}
			}else if(itemStr.equals("д������")){
				if(connFlag == false)
				{
					Toast.makeText(getApplicationContext(), "���Ƚ�������", 0).show();
					return;
				}else{
					Intent writeIntent = new Intent(BluetoothActivity.this, WriteActivity.class);
					startActivity(writeIntent);
				}
			}else if(itemStr.equals("��������")){
				if(connFlag == false)
				{
					Toast.makeText(getApplicationContext(), "���Ƚ�������", 0).show();
					return;
				}
				Intent settingIntent = new Intent(BluetoothActivity.this, SettingActivity.class);
				startActivity(settingIntent);
			}else if(itemStr.equals("������ǩ")){
				if(connFlag == false)
				{
					Toast.makeText(getApplicationContext(), "���Ƚ�������", 0).show();
					return;
				}
				Intent lockIntent = new Intent(BluetoothActivity.this, LockActivity.class);
				startActivity(lockIntent);
			}else if(itemStr.equals("���ٱ�ǩ")){
				if(connFlag == false)
				{
					Toast.makeText(getApplicationContext(), "���Ƚ�������", 0).show();
					return;
				}
				Intent killIntent = new Intent(BluetoothActivity.this, KillActivity.class);
				startActivity(killIntent);
			}			
			else if(itemStr.equals("�˳�")){
				finish();
			}
		}		
		
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			//ȡ��ע��
			if(mReceiver != null){
				unregisterReceiver(mReceiver);
				mReceiver = null;
			}
			

			if (connectThread != null) {
				connectThread.interrupt();
			}
			if (connectedThread != null) {
				connectedThread.interrupt();
			}
			if (acceptThread != null) {
				acceptThread.interrupt();
			}
			if (socket != null) {
				 try {
				 socket.close();
				 } catch (IOException e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
				 }
				 }
			if (btAdapter.isEnabled()) {
				Toast.makeText(this, "���ֶ��ر�����", Toast.LENGTH_SHORT).show();
			}
			finish();
		}
		return super.onKeyDown(keyCode, event);
	}
	
	/*
	 * �˳�����ʱ����һ�º��£�ȡ��ע��㲥����������ֹ�̣߳��ر�socket
	 */
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		//ȡ��ע��
		if(mReceiver != null){
			unregisterReceiver(mReceiver);
			mReceiver = null;
		}
		
		if (connectThread != null) {
			connectThread.interrupt();
		}
		if (connectedThread != null) {
			connectedThread.interrupt();
		}
		if (socket != null) {
			 try {
			 socket.close();
			 } catch (IOException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
			 }
			 }

	}
}
