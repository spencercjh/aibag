package com.jr.uhf;

import com.jr.uhf.InventoryTagActivity.ButtonreadtagListner;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	private Button buttonBluetooth ;
	private Button buttonSerial;
	private Button buttonExit ;
	private Button buttonUSB ;
	private Button buttonHelp;
	MyActivityManager manager ;
	private TextView textTitle;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		textTitle = (TextView) findViewById(R.id.textView_title);
		textTitle.setText("��ѡ��������");
		manager = (MyActivityManager)getApplication();
		manager.addActivity(this);
		//��ʼUI
		this.initView();
		//������ť
		this.listner();
	}
	/**
	 * ��ʼUI
	 * @author jimmy
	 * @Date 2015-1-13
	 */
	private void initView(){
		buttonBluetooth = (Button) findViewById(R.id.buttonBluetoothOption);
		buttonSerial = (Button) findViewById(R.id.buttonSerialOption);
		buttonExit = (Button) findViewById(R.id.button_exit);
		buttonUSB = (Button) findViewById(R.id.buttonUSBOption);
		buttonHelp = (Button) findViewById(R.id.button_help);
	}
	/**
	 * ������ť
	 * @author jimmy
	 * @Date 2015-1-13
	 */
	private void listner(){
		//�����������
		buttonBluetooth.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, BluetoothActivity.class);
				startActivity(intent);
				
			}
		});
		//���ڲ������
		buttonSerial.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent serialportIntent = new Intent(MainActivity.this, SerialportSettingActivity.class);
				startActivity(serialportIntent);
				
			}
		});
		//help
				buttonHelp.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						Intent helpIntent = new Intent(MainActivity.this, HelpAcivity.class);
						startActivity(helpIntent);
					}
				});
		//USB
		buttonUSB.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent UsbIntent = new Intent(MainActivity.this, UsbSettingActivity.class);
				startActivity(UsbIntent);
			}
		});
		//�˳�
		buttonExit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity.this.exit();
				
			}
		});
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			this.exit();
		}
		return super.onKeyDown(keyCode, event);
	}
	/**
	 * �˳�
	 * @author jimmy
	 * @Date 2015-1-14
	 */
	public void exit(){
		new AlertDialog.Builder(this)
		.setTitle("�˳�����")
		.setMessage("�Ƿ��˳�����")
		.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				manager.exit();
			}
		}).setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {

			}
		}).show();
	}
}
